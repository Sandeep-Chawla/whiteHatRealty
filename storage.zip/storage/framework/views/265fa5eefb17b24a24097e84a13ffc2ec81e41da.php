

<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('customCss'); ?>
<link rel="stylesheet" href="<?php echo e(url('assets/customs/css/youtube-video.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="page_title">
                <div class="d-flex justify-content-between">
                    <div>
                        <h2><?php echo e($title); ?></h2>
                    </div>
                    <a class="btn btn-primary pt-2" href="<?php echo e(route('youtube-videos.index')); ?>">
                        <span class="fa fa-bars"></span> All List
                    </a>
                </div>
            </div>

            <div class="card contentCard">
                <div class="card-body">
                    <div class="col-md-6">
                    <form method="POST" action="<?php echo e(route('youtube-videos.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="thumbnail">Video Thumbnail:</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="thumbnail" placeholder="Thumbnail">
                            
                        </div>
                        <div class="form-group">
                            <label for="source">Video Source:</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['video_source'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="video_source" placeholder="Video Source">
                        </div>
                        <div class="form-group">
                            <label for="title">Title:</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title" placeholder="Title">
                        </div>
                        <div class="form-group">
                            <label for="description">Video Description:</label>
                            <textarea name="description" id="" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></textarea>
                        </div><br>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\White Hat Reality\whiteHatRealty\resources\views/admin/youtube-videos/add.blade.php ENDPATH**/ ?>