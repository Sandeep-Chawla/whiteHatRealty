

<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('customCss'); ?>
<link rel="stylesheet" href="<?php echo e(url('assets/customs/css/youtube-video.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="page_title">
                <div class="d-flex justify-content-between">
                    <div>
                        <h2><?php echo e($title); ?></h2>
                    </div>
                    <a class="btn btn-primary pt-2" href="<?php echo e(route('youtube-videos.create')); ?>">
                        <span class="fa fa-plus"></span> Add New
                    </a>
                </div>
            </div>

            <div class="card contentCard">
            <h2>Hello</h2>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\White Hat Reality\whiteHatRealty\resources\views/admin/youtube-videos/list.blade.php ENDPATH**/ ?>