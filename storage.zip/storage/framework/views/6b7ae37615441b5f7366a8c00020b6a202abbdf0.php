

<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('customCss'); ?>
<link rel="stylesheet" href="<?php echo e(url('assets/customs/css/dashboard.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-3">
    <div class="row">
        <div class="col-md-12">
            <div class="page_title">
                <h2>Dashboard</h2>
            </div>
        </div>
    </div>
    <div class="row">

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\White Hat Reality\whiteHatRealty\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>