<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'White Hat Realty'); ?></title>

    <link rel="stylesheet" href="<?php echo e(url('assets/libraries/css/bootstrap.min.css')); ?>">
    <?php echo $__env->yieldContent('customCss'); ?>

    <script src="<?php echo e(url('assets/libraries/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/libraries/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(url('assets/libraries/js/fontsawesome.js')); ?>"></script>

</head>

<body>
    <!-- Main content -->
    <div class="app">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <?php echo $__env->yieldContent('customJs'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\White Hat Reality\whiteHatRealty\resources\views/layouts/app.blade.php ENDPATH**/ ?>