<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'White Hat Realty'); ?></title>

    <link rel="stylesheet" href="<?php echo e(url('assets/libraries/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('assets/customs/css/admin.css')); ?>">
    <?php echo $__env->yieldContent('customCss'); ?>

</head>


<body class="dashboard dashboard_1">
      <div class="full_container">
         <div class="inner_container">
         <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

         <!-- right content -->
         <div id="content">
                <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               
               <!-- end topbar -->
               <!-- dashboard inner -->
               <div class="midde_cont">
                  <?php echo $__env->yieldContent('content'); ?>
                  
                  
               </div>
               <!-- end dashboard inner -->
            </div>
         </div>
      </div>
      <!-- jQuery -->
      
      <script src="<?php echo e(url('assets/libraries/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(url('assets/libraries/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/libraries/js/fontsawesome.js')); ?>"></script>
   </body>

</html><?php /**PATH C:\xampp\htdocs\White Hat Reality\whiteHatRealty\resources\views/layouts/admin-app.blade.php ENDPATH**/ ?>